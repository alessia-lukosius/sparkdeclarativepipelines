# Databricks notebook source
# MAGIC %md
# MAGIC # AlessiaAirlines — Project Setup
# MAGIC
# MAGIC Cria a estrutura base do projeto no Unity Catalog:
# MAGIC - Catálogo `alessiaairlines`
# MAGIC - Schema `landing` (volumes de ingestão)
# MAGIC - Schema `sdp` (camadas Bronze, Silver e Gold — alvo único dos pipelines SDP)
# MAGIC - Volume `landing.documents` (arquivos diários de vendas de passagens)
# MAGIC - Volume `landing.agencies` (arquivos mensais de agências)
# MAGIC
# MAGIC **Execute este notebook uma única vez antes de acionar qualquer pipeline SDP.**

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parâmetros

# COMMAND ----------

CATALOG       = "alessiaairlines"
SCHEMA_LANDING = "landing"
SCHEMA_SDP     = "sdp"
VOL_DOCUMENTS  = "documents"
VOL_AGENCIES   = "agencies"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Catálogo

# COMMAND ----------

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"USE CATALOG {CATALOG}")
print(f"✅ Catálogo '{CATALOG}' pronto.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Schemas

# COMMAND ----------

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA_LANDING}")
print(f"✅ Schema '{CATALOG}.{SCHEMA_LANDING}' pronto.")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA_SDP}")
print(f"✅ Schema '{CATALOG}.{SCHEMA_SDP}' pronto.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Volumes de Landing

# COMMAND ----------

spark.sql(f"""
    CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA_LANDING}.{VOL_DOCUMENTS}
    COMMENT 'Arquivos CSV diários de vendas de passagens (documents_YYYYMMDD.csv)'
""")
print(f"✅ Volume '{CATALOG}.{SCHEMA_LANDING}.{VOL_DOCUMENTS}' pronto.")

spark.sql(f"""
    CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA_LANDING}.{VOL_AGENCIES}
    COMMENT 'Arquivos CSV mensais de agências de viagem (agencies_YYYYMM.csv)'
""")
print(f"✅ Volume '{CATALOG}.{SCHEMA_LANDING}.{VOL_AGENCIES}' pronto.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Verificação Final

# COMMAND ----------

print("=" * 55)
print("RESUMO DA ESTRUTURA CRIADA")
print("=" * 55)

schemas = spark.sql(f"SHOW SCHEMAS IN {CATALOG}").collect()
print(f"\n📁 Catálogo: {CATALOG}")
print(f"   Schemas: {[r.databaseName for r in schemas]}")

vols = spark.sql(f"SHOW VOLUMES IN {CATALOG}.{SCHEMA_LANDING}").collect()
print(f"\n📂 Volumes em '{CATALOG}.{SCHEMA_LANDING}':")
for v in vols:
    path = f"/Volumes/{CATALOG}/{SCHEMA_LANDING}/{v.volume_name}"
    print(f"   └── {v.volume_name}  →  {path}")

print(f"\n📂 Schema de destino dos pipelines SDP: '{CATALOG}.{SCHEMA_SDP}'")

print("\n" + "=" * 55)
print("✅ Setup concluído! Próximos passos:")
print("   1. Faça upload dos CSVs de amostra nos volumes acima")
print("   2. Configure os pipelines SDP em Settings → Advanced → Configuration:")
print(f"      CATALOG       = {CATALOG}")
print(f"      VOL_DOCUMENTS = {VOL_DOCUMENTS}")
print(f"      VOL_AGENCIES  = {VOL_AGENCIES}")
print("   3. Execute os pipelines na ordem: 01 → 02 → 03")
print("=" * 55)
